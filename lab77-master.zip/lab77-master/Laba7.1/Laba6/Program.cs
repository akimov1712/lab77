﻿using System;
using System.Collections.Generic;

struct TableRow
{
	public string Column1;
	public string Column2;
	public int Column3;
	public string Column4;

	public int getYear()
	{
		return Column3;
	}
}

class Program
{
	static List<TableRow> table = new List<TableRow>();
	static List<string> log = new List<string>();
	static DateTime startTime = DateTime.Now;
	
	

	static void Main()
	{
		while (true)
		{
			Console.WriteLine("Выберите действие:");
			Console.WriteLine("1 – Просмотр таблицы");
			Console.WriteLine("2 – Добавить запись");
			Console.WriteLine("3 – Удалить запись");
			Console.WriteLine("4 – Обновить запись");
			Console.WriteLine("5 – Поиск записей");
			Console.WriteLine("6 – Просмотреть лог");
			Console.WriteLine("7 - Выход");

			int choice = ReadInt("Введите номер действия: ");

			switch (choice)
			{
				case 1:
					ViewTable();
					startTime = DateTime.Now;
					break;

				case 2:
					AddRow();
					startTime = DateTime.Now;
					break;

				case 3:
					RemoveRow();
					startTime = DateTime.Now;
					break;

				case 4:
					UpdateRow();
					startTime = DateTime.Now;
					break;

				case 5:
					SearchRows();
					startTime = DateTime.Now;
					break;

				case 6:
					ViewLog();
					break;

				case 7:
					return;

				default:
					Console.WriteLine("Некорректный номер действия");
					break;
			}
		}
	}

	static void ViewTable()
	{
		Console.WriteLine("|                 Каталог библиотеки                 |");
		Console.WriteLine("-----------------------------------------------------");

		for (int i = 0; i < table.Count - 1; i++)
		{
			int minIndex = i;
			for (int j = i + 1; j < table.Count; j++)
			{
				if (table[j].getYear() < table[minIndex].getYear())
				{
					minIndex = j;
				}
			}
			if (minIndex != i)
			{
				TableRow temp = table[i];
				table[i] = table[minIndex];
				table[minIndex] = temp;
			}
		}

		for (int i = 0; i < table.Count; i++)
		{
			TableRow row = table[i];
			Console.WriteLine($"| {row.Column1,-10} | {row.Column2,-10} | {row.Column3,-10} | {row.Column4,-10} |");
		}
		Console.WriteLine("-----------------------------------------------------");
		Console.WriteLine("|Перечисляемый тип: Х - художественная литература; У - учебная лит-ра; С - справочная лит-ра|");
		Console.WriteLine("");
	}

	static void AddRow()
	{
		TableRow row = new TableRow();

		row.Column1 = ReadString("Введите значение для Колонки 1 (Автор): ");
		row.Column2 = ReadString("Введите значение для Колонки 2 (Название): ");
		row.Column3 = ReadInt("Введите значение для Колонки 3 (год): ");
		row.Column4 = ReadString("Введите значение для Колонки 4 ( Х | У | С ): ");

		table.Add(row);
		log.Add($"Добавлена запись: {row.Column1}, {row.Column2}, {row.Column3}, {row.Column4}");
	}

	static void RemoveRow()
	{
		int index = ReadInt("Введите номер записи для удаления: ");

		if (index >= 1 && index <= table.Count)
		{
			TableRow row = table[index - 1];
			table.RemoveAt(index - 1);
			log.Add($"Удалена запись: {row.Column1}, {row.Column2}, {row.Column3}, {row.Column4}");
		}
		else
		{
			Console.WriteLine("Некорректный номер записи");
		}
	}

	static void UpdateRow()
	{
		int index = ReadInt("Введите номер записи для обновления: ");

		if (index >= 1 && index <= table.Count)
		{
			TableRow row = table[index - 1];

			row.Column1 = ReadString("Введите новое значение для Колонки 1 (Автор): ");
			row.Column2 = ReadString("Введите новое значение для Колонки 2 (Название): ");
			row.Column3 = ReadInt("Введите новое значение для Колонки 3 (год): ");
			row.Column4 = ReadString("Введите новое значение для Колонки 4 ( Х | У | С ): ");
			table[index - 1] = row;
			log.Add($"Обновлена запись: {row.Column1}, {row.Column2}, {row.Column3}, {row.Column4}");
		}
		else
		{
			Console.WriteLine("Некорректный номер записи");
		}
	}

	static void SearchRows()
	{
		string searchQuery = ReadString("Введите автора для поиска: ");
		List<TableRow> matchingRows = new List<TableRow>();

		foreach (TableRow row in table)
		{
			if (row.Column1.Contains(searchQuery))
			{
				matchingRows.Add(row);
			}
		}

		Console.WriteLine($"Найдено {matchingRows.Count} записей:");
		ViewTable(matchingRows);
	}

	static void ViewLog()
	{
		Console.WriteLine("Лог действий:");
		Console.WriteLine("-------------");

		foreach (string entry in log)
		{
			Console.WriteLine(entry);
		}
		Console.WriteLine();

		DateTime currentTime = DateTime.Now;

		TimeSpan diff = currentTime - startTime;

		Console.WriteLine($"{diff.Hours.ToString().PadLeft(2, '0')}:{diff.Minutes.ToString().PadLeft(2, '0')}:{diff.Seconds.ToString().PadLeft(2, '0')} – Самый долгий период бездействия пользователя");
	}

	static void ViewTable(List<TableRow> rows)
	{
		Console.WriteLine("| Автор книги | Название | Год выпуска | Группа |");
		Console.WriteLine("-----------------------------------------------------");

		for (int i = 0; i < rows.Count; i++)
		{
			TableRow row = rows[i];
			Console.WriteLine($"| {row.Column1,-10} | {row.Column2,-10} | {row.Column3,-10} | {row.Column4,-10} |");
		}
	}

	static string ReadString(string prompt)
	{
		Console.Write(prompt);
		return Console.ReadLine();
	}

	static int ReadInt(string prompt)
	{
		while (true)
		{
			Console.Write(prompt);
			string input = Console.ReadLine();

			if (int.TryParse(input, out int result))
			{
				return result;
			}
			else
			{
				Console.WriteLine("Некорректный формат числа");
			}
		}
	}
}
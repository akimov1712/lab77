﻿using System;
using System.Diagnostics;
using System.IO;

namespace SortingAlgorithms
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int[] arr1 = generateRandomArray();
            
            compareSelectionSort(arr1);
            compareInsertionSort(arr1);
            compareBubbleSort(arr1);
            compareShakerSort(arr1);
            compareShellSort(arr1);
            
        }

        static void compareSelectionSort(int[] arr1)
        {
            int[] arr2 = sortArray(arr1, true);
            int[] arr3 = sortArray(arr1, false);

            Stopwatch stopwatch = new Stopwatch();

            using (StreamWriter writer = new StreamWriter(@"H:\Rider projects\laba6.2\laba6.2\sorted.dat"))
            {

                // Сортировка выбором
                Console.WriteLine("Сортировка выбором:");
                writer.WriteLine("Сортировка выбором:");

                stopwatch.Restart();
                selectionSort(arr1);
                stopwatch.Stop();
                checkSorted(arr1);
                Console.WriteLine($"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine($"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");

                stopwatch.Restart();
                selectionSort(arr2);
                stopwatch.Stop();
                Console.WriteLine($"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine($"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");

                stopwatch.Restart();
                selectionSort(arr3);
                stopwatch.Stop();
                Console.WriteLine($"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine($"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
            }

        }

        static void compareInsertionSort(int[] arr1)
        {
            int[] arr2 = sortArray(arr1, true);
            int[] arr3 = sortArray(arr1, false);

            Stopwatch stopwatch = new Stopwatch();

            using (StreamWriter writer = new StreamWriter(@"H:\Rider projects\laba6.2\laba6.2\sorted.dat", true))
            {
                // Сортировка вставками
                Console.WriteLine("\nСортировка вставками:");
                writer.WriteLine("\nСортировка вставками:");


                stopwatch.Restart();
                insertionSort(arr1);
                checkSorted(arr1);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                insertionSort(arr2);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                insertionSort(arr3);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
            }

        }
        
        static void compareBubbleSort(int[] arr1)
        {
            int[] arr2 = sortArray(arr1, true);
            int[] arr3 = sortArray(arr1, false);

            Stopwatch stopwatch = new Stopwatch();

            using (StreamWriter writer = new StreamWriter(@"H:\Rider projects\laba6.2\laba6.2\sorted.dat", true))
            {
                // Сортировка пузырьком
                Console.WriteLine("\nСортировка пузырьком:");
                writer.WriteLine("\nСортировка пузырьком:");


                stopwatch.Restart();
                bubbleSort(arr1);
                checkSorted(arr1);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                bubbleSort(arr2);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                bubbleSort(arr3);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
            }
        }
        
        static void compareShakerSort(int[] arr1)
        {
            int[] arr2 = sortArray(arr1, true);
            int[] arr3 = sortArray(arr1, false);

            Stopwatch stopwatch = new Stopwatch();

            using (StreamWriter writer = new StreamWriter(@"H:\Rider projects\laba6.2\laba6.2\sorted.dat", true))
            {
                // Сортировка шейкером
                Console.WriteLine("\nСортировка шейкер:");
                writer.WriteLine("\nСортировка шейкер:");


                stopwatch.Restart();
                shakerSort(arr1);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                shakerSort(arr2);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                shakerSort(arr3);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
            }
        }
        
        static void compareShellSort(int[] arr1)
        {
            int[] arr2 = sortArray(arr1, true);
            int[] arr3 = sortArray(arr1, false);

            Stopwatch stopwatch = new Stopwatch();
            using (StreamWriter writer = new StreamWriter(@"H:\Rider projects\laba6.2\laba6.2\sorted.dat", true))
            {
                // Сортировка шелом
                Console.WriteLine("\nСортировка shell:");
                writer.WriteLine("\nСортировка shell:");


                stopwatch.Restart();
                shellSort(arr1);
                checkSorted(arr1);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Рандомный массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                shellSort(arr2);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Возрастающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");


                stopwatch.Restart();
                shellSort(arr3);
                stopwatch.Stop();
                Console.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
                writer.WriteLine(
                    $"Убывающий массив: {stopwatch.Elapsed.Seconds}:{stopwatch.ElapsedMilliseconds % 1000} sec");
            }
        }

        public static int[] generateRandomArray()
        {
            Random random = new Random();

            int[] arr = new int[10000];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = random.Next();
            }

            return arr;
        }

        public static int[] sortArray(int[] arr, bool state)
        {
            if (state)
            {
                int n = arr.Length;
                for (int i = 0; i < n - 1; i++)
                {
                    for (int j = 0; j < n - i - 1; j++)
                    {
                        if (arr[j] > arr[j + 1])
                        {
                            int temp = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }

                return arr;
            } else if (!state)
            {
                int n = arr.Length;
                for (int i = 0; i < n - 1; i++)
                {
                    for (int j = 0; j < n - i - 1; j++)
                    {
                        if (arr[j] < arr[j + 1])
                        {
                            int temp = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }

                return arr;
            }
            return null;
        }
        

        // выбором
        public static void selectionSort(int[] arr)
        {
            int comparisons = 0;
            int swaps = 0;


            for (int i = 0; i < arr.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < arr.Length; j++)
                {
                    comparisons++;
                    if (arr[j] < arr[minIndex])
                    {
                        minIndex = j;
                    }
                }

                if (minIndex != i)
                {
                    int temp = arr[i];
                    arr[i] = arr[minIndex];
                    arr[minIndex] = temp;
                    swaps++;
                }
            }

        }

        //вставкками
        public static void insertionSort(int[] arr)
        {
            int comparisons = 0;
            int swaps = 0;
            

            for (int i = 1; i < arr.Length; i++)
            {
                int key = arr[i];
                int j = i - 1;

                while (j >= 0 && arr[j] > key)
                {
                    comparisons++;
                    arr[j + 1] = arr[j];
                    j = j - 1;
                    swaps++;
                }

                arr[j + 1] = key;
                swaps++;
            }
        }

        //пузырьком
        public static void bubbleSort(int[] arr)
        {
            int comparisons = 0;
            int swaps = 0;
            

            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j = 0; j < arr.Length - i - 1; j++)
                {
                    comparisons++;
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                        swaps++;
                    }
                }
            }
        }

        //шейкером
        public static void shakerSort(int[] arr)
        {
            int comparisons = 0;
            int swaps = 0;
            

            int left = 0, right = arr.Length - 1;
            while (left < right)
            {
                for (int i = left; i < right; i++)
                {
                    comparisons++;
                    if (arr[i] > arr[i + 1])
                    {
                        int temp = arr[i];
                        arr[i] = arr[i + 1];
                        arr[i + 1] = temp;
                        swaps++;
                    }
                }

                right--;

                for (int i = right; i > left; i--)
                {
                    comparisons++;
                    if (arr[i - 1] > arr[i])
                    {
                        int temp = arr[i];
                        arr[i] = arr[i - 1];
                        arr[i - 1] = temp;
                        swaps++;
                    }
                }

                left++;
            }
        }

        public static void shellSort(int[] arr)
        {
            int comparisons = 0;
            int swaps = 0;

            int n = arr.Length;



            for (int gap = n / 2; gap > 0; gap /= 2)
            {
                for (int i = gap; i < n; i++)
                {
                    int temp = arr[i];
                    int j;
                    for (j = i; j >= gap && arr[j - gap] > temp; j -= gap)
                    {
                        arr[j] = arr[j - gap];
                        swaps++;
                        comparisons++;
                    }

                    arr[j] = temp;
                    swaps++;

                    comparisons++;
                }

            }
        }
        
        public static bool isSorted(int[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                if (array[i] > array[i + 1])
                {
                    return false;
                }
            }

            return true;
        }

        static void checkSorted(int[] array)
        {
            if (isSorted(array))
            {
                Console.WriteLine("Массив был успешно отсортирован.");
            }
            else
            {
                Console.WriteLine("Массив не был отсортирован.");
            }
        }
    }
}